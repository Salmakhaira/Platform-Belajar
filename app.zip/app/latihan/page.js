'use client'
import { useState, useEffect } from 'react'
import { useAuth } from '@/components/AuthContext'
import { supabase } from '@/lib/supabase'
import { useRouter } from 'next/navigation'
import Navbar from '@/components/Navbar'
import Timer from '@/components/Timer'
import { ChevronLeft, ChevronRight, Send, Lock, CheckCircle } from 'lucide-react'

const SUBMATERI = [
  { code: 'PU', name: 'Penalaran Umum', color: 'blue' },
  { code: 'PPU', name: 'Pengetahuan & Pemahaman Umum', color: 'green' },
  { code: 'PBM', name: 'Pemahaman Bacaan & Menulis', color: 'yellow' },
  { code: 'PK', name: 'Pengetahuan Kuantitatif', color: 'red' },
  { code: 'LBI', name: 'Literasi Bahasa Indonesia', color: 'orange' },
  { code: 'LBE', name: 'Literasi Bahasa Inggris', color: 'purple' },
  { code: 'PM', name: 'Penalaran Matematika', color: 'pink' }
]

export default function Latihan() {
  const { user } = useAuth()
  const router = useRouter()

  const [stage, setStage] = useState(1) // 1: pilih submateri, 2: pilih batch, 3: latihan
  const [selectedSubmateri, setSelectedSubmateri] = useState(null)
  const [batchProgress, setBatchProgress] = useState([])
  const [selectedBatch, setSelectedBatch] = useState(null)
  const [questions, setQuestions] = useState([])
  const [currentIndex, setCurrentIndex] = useState(0)
  const [answers, setAnswers] = useState({})
  const [sessionId, setSessionId] = useState(null)
  const [isActive, setIsActive] = useState(false)
  const [loading, setLoading] = useState(false)
  const [startTime, setStartTime] = useState(null)

  useEffect(function() {
    if (!user) {
      router.push('/login')
      return
    }
    checkPretest()
  }, [user, router])

  async function checkPretest() {
    const { data } = await supabase
      .from('student_profiles')
      .select('pretest_completed')
      .eq('user_id', user.id)
      .single()

    if (!data || !data.pretest_completed) {
      alert('Kamu harus menyelesaikan Initial Test terlebih dahulu!')
      router.push('/pretest')
    }
  }

  async function selectSubmateri(code) {
    setSelectedSubmateri(code)
    setLoading(true)

    // Fetch batch progress untuk submateri ini
    const { data, error } = await supabase
      .from('batch_progress')
      .select('*')
      .eq('user_id', user.id)
      .eq('submateri', code)
      .order('batch_number')

    if (error) {
      console.error('Error fetching batch progress:', error)
      setLoading(false)
      return
    }

    // Kalau belum ada batch progress, create default (Batch 1 unlocked)
    if (!data || data.length === 0) {
      await supabase
        .from('batch_progress')
        .insert({
          user_id: user.id,
          submateri: code,
          batch_number: 1,
          is_unlocked: true,
          is_completed: false
        })

      setBatchProgress([{ batch_number: 1, is_unlocked: true, is_completed: false, score: null }])
    } else {
      setBatchProgress(data)
    }

    setStage(2)
    setLoading(false)
  }

  async function startBatch(batchNum) {
    setLoading(true)

    // Fetch questions untuk batch ini
    const { data: questionsData, error } = await supabase
      .from('questions')
      .select('*')
      .eq('submateri', selectedSubmateri)
      .eq('batch_number', batchNum)
      .eq('is_pretest', false)

    if (error || !questionsData || questionsData.length === 0) {
      alert('Error memuat soal: ' + (error?.message || 'Soal tidak ditemukan'))
      setLoading(false)
      return
    }

    // Create session
    const { data: session, error: sessionError } = await supabase
      .from('sessions')
      .insert({
        user_id: user.id,
        session_type: 'latihan',
        submateri: selectedSubmateri,
        duration_minutes: 30,
        start_time: new Date().toISOString(),
        packet: `Batch ${batchNum}`
      })
      .select()
      .single()

    if (sessionError) {
      alert('Error creating session: ' + sessionError.message)
      setLoading(false)
      return
    }

    setQuestions(questionsData)
    setSessionId(session.id)
    setSelectedBatch(batchNum)
    setIsActive(true)
    setStartTime(Date.now())
    setStage(3)
    setLoading(false)
  }

  function handleAnswer(questionId, answer) {
    setAnswers({
      ...answers,
      [questionId]: {
        answer,
        timeTaken: Math.floor((Date.now() - startTime) / 1000)
      }
    })
  }

  async function submitAnswers(autoSubmit = false) {
    if (!autoSubmit && !confirm('Yakin ingin submit jawaban?')) return

    if (autoSubmit) {
      alert('Waktu habis! Jawaban akan otomatis terkirim.')
    }

    setIsActive(false)
    setLoading(true)

    // Update session
    await supabase
      .from('sessions')
      .update({
        end_time: new Date().toISOString(),
        is_completed: true,
        auto_submitted: autoSubmit
      })
      .eq('id', sessionId)

    // Insert answers
    const answersToInsert = questions.map(function(q) {
      return {
        session_id: sessionId,
        question_id: q.id,
        user_answer: answers[q.id]?.answer || null,
        is_correct: answers[q.id]?.answer === q.correct_answer,
        time_taken_seconds: answers[q.id]?.timeTaken || 0
      }
    })

    await supabase.from('user_answers').insert(answersToInsert)

    // Calculate score
    const correctCount = answersToInsert.filter(function(a) { return a.is_correct }).length
    const totalQuestions = questions.length
    const scorePercentage = Math.round((correctCount / totalQuestions) * 100)

    // Update batch progress
    await supabase
      .from('batch_progress')
      .upsert({
        user_id: user.id,
        submateri: selectedSubmateri,
        batch_number: selectedBatch,
        is_unlocked: true,
        is_completed: true,
        score: scorePercentage,
        total_questions: totalQuestions,
        correct_answers: correctCount,
        completed_at: new Date().toISOString()
      })

    // Unlock batch berikutnya kalau score >= 70%
    if (scorePercentage >= 70) {
      await supabase
        .from('batch_progress')
        .upsert({
          user_id: user.id,
          submateri: selectedSubmateri,
          batch_number: selectedBatch + 1,
          is_unlocked: true,
          is_completed: false
        })
    }

    setLoading(false)
    router.push(`/review/${sessionId}`)
  }

  if (!user) return null

  // ========== STAGE 1: Pilih Submateri ==========
  if (stage === 1) {
    return (
      <div>
        <Navbar />
        <div className="min-h-screen bg-gray-50 p-8">
          <div className="max-w-6xl mx-auto">
            <h1 className="text-4xl font-bold mb-2">📝 Latihan Soal</h1>
            <p className="text-gray-600 mb-8">Pilih submateri untuk memulai latihan</p>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {SUBMATERI.map(function(sub) {
                return (
                  <button
                    key={sub.code}
                    onClick={function() { selectSubmateri(sub.code) }}
                    className="bg-white p-6 rounded-xl shadow hover:shadow-lg border-2 border-gray-100 hover:border-blue-300 transition-all text-left"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-bold">
                        {sub.code}
                      </span>
                      <ChevronRight size={24} className="text-gray-400" />
                    </div>
                    <p className="font-semibold text-gray-800">{sub.name}</p>
                    <p className="text-sm text-gray-500 mt-2">Latihan per batch dengan sistem unlock</p>
                  </button>
                )
              })}
            </div>
          </div>
        </div>
      </div>
    )
  }

  // ========== STAGE 2: Pilih Batch ==========
  if (stage === 2) {
    const submateriData = SUBMATERI.find(function(s) { return s.code === selectedSubmateri })

    return (
      <div>
        <Navbar />
        <div className="min-h-screen bg-gray-50 p-8">
          <div className="max-w-4xl mx-auto">
            <button
              onClick={function() { setStage(1) }}
              className="flex items-center gap-2 text-gray-600 hover:text-gray-800 mb-6"
            >
              <ChevronLeft size={20} />
              Kembali ke pilih submateri
            </button>

            <div className="bg-white rounded-xl shadow-lg p-8 mb-6">
              <div className="flex items-center gap-4 mb-6">
                <span className="bg-blue-100 text-blue-800 px-4 py-2 rounded-full text-lg font-bold">
                  {selectedSubmateri}
                </span>
                <div>
                  <h1 className="text-2xl font-bold">{submateriData?.name}</h1>
                  <p className="text-gray-500">Pilih batch untuk memulai latihan</p>
                </div>
              </div>

              <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded-r-lg mb-6">
                <p className="text-blue-800 text-sm font-medium">
                  💡 Sistem Batch: Kamu harus mendapat minimal <strong>70%</strong> untuk unlock batch berikutnya.
                </p>
              </div>

              {loading ? (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-4 border-blue-600 mx-auto"></div>
                  <p className="text-gray-500 mt-4">Memuat batch...</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {[1, 2, 3].map(function(batchNum) {
                    const batchData = batchProgress.find(function(b) { return b.batch_number === batchNum })
                    const isUnlocked = batchData?.is_unlocked || false
                    const isCompleted = batchData?.is_completed || false
                    const score = batchData?.score || null

                    return (
                      <div
                        key={batchNum}
                        className={'rounded-xl p-6 border-2 transition-all ' + (isUnlocked ? 'bg-white hover:shadow-md' : 'bg-gray-50 border-gray-200')}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            {isCompleted ? (
                              <CheckCircle size={32} className="text-green-600" />
                            ) : !isUnlocked ? (
                              <Lock size={32} className="text-gray-400" />
                            ) : (
                              <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                                <span className="text-blue-600 font-bold">{batchNum}</span>
                              </div>
                            )}
                            <div>
                              <p className="font-bold text-lg">Batch {batchNum}</p>
                              {isCompleted && score !== null ? (
                                <p className="text-sm text-gray-600">
                                  Skor: <span className={'font-bold ' + (score >= 70 ? 'text-green-600' : 'text-red-600')}>
                                    {score}%
                                  </span>
                                </p>
                              ) : !isUnlocked ? (
                                <p className="text-sm text-gray-500">🔒 Terkunci - selesaikan batch sebelumnya dulu</p>
                              ) : (
                                <p className="text-sm text-gray-500">Belum dikerjakan</p>
                              )}
                            </div>
                          </div>
                          <button
                            onClick={function() { startBatch(batchNum) }}
                            disabled={!isUnlocked || loading}
                            className={'px-6 py-3 rounded-xl font-medium transition-all ' + (isUnlocked ? 'bg-blue-600 text-white hover:bg-blue-700' : 'bg-gray-200 text-gray-400 cursor-not-allowed')}
                          >
                            {isCompleted ? 'Ulangi' : 'Mulai'}
                          </button>
                        </div>
                      </div>
                    )
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    )
  }

  // ========== STAGE 3: Latihan Soal ==========
  if (stage === 3) {
    const currentQuestion = questions[currentIndex]
    const answeredCount = Object.keys(answers).length

    return (
      <div>
        <Navbar />
        <Timer
          durationMinutes={30}
          onTimeUp={function() { submitAnswers(true) }}
          isActive={isActive}
        />

        <div className="min-h-screen bg-gray-50 pt-20 pb-8 px-4">
          <div className="max-w-4xl mx-auto">

            <div className="bg-white rounded-lg p-4 mb-6 shadow">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium">
                  {selectedSubmateri} — Batch {selectedBatch} — Soal {currentIndex + 1}/{questions.length}
                </span>
                <span className="text-sm text-gray-600">
                  Terjawab: {answeredCount}/{questions.length}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-blue-600 h-2 rounded-full transition-all"
                  style={{ width: ((currentIndex + 1) / questions.length * 100) + '%' }}
                />
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-8 mb-6">
              <h2 className="text-xl font-medium mb-6 leading-relaxed">
                {currentQuestion?.question_text}
              </h2>
              <div className="space-y-3">
                {['A', 'B', 'C', 'D', 'E'].map(function(opt) {
                  const isSelected = answers[currentQuestion?.id]?.answer === opt
                  return (
                    <button
                      key={opt}
                      onClick={function() { handleAnswer(currentQuestion.id, opt) }}
                      className={'w-full text-left p-4 rounded-xl border-2 transition-all ' + (isSelected ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-blue-300')}
                    >
                      <span className="font-bold mr-3">{opt}.</span>
                      {currentQuestion?.[`option_${opt.toLowerCase()}`]}
                    </button>
                  )
                })}
              </div>
            </div>

            <div className="flex justify-between items-center mb-6">
              <button
                onClick={function() { setCurrentIndex(Math.max(0, currentIndex - 1)) }}
                disabled={currentIndex === 0}
                className="flex items-center gap-2 px-6 py-3 bg-gray-200 rounded-lg hover:bg-gray-300 disabled:opacity-50"
              >
                <ChevronLeft size={20} />
                Sebelumnya
              </button>
              {currentIndex === questions.length - 1 ? (
                <button
                  onClick={function() { submitAnswers(false) }}
                  disabled={loading}
                  className="flex items-center gap-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50"
                >
                  <Send size={20} />
                  {loading ? 'Menyimpan...' : 'Submit'}
                </button>
              ) : (
                <button
                  onClick={function() { setCurrentIndex(Math.min(questions.length - 1, currentIndex + 1)) }}
                  className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Selanjutnya
                  <ChevronRight size={20} />
                </button>
              )}
            </div>

            <div className="bg-white rounded-lg p-6 shadow">
              <h3 className="font-bold mb-4">Navigasi Soal</h3>
              <div className="grid grid-cols-10 gap-2">
                {questions.map(function(q, idx) {
                  const isAnswered = answers[q.id]
                  const isCurrent = idx === currentIndex
                  return (
                    <button
                      key={q.id}
                      onClick={function() { setCurrentIndex(idx) }}
                      className={'aspect-square rounded-lg font-bold text-sm transition-all ' + (isCurrent ? 'bg-blue-600 text-white' : isAnswered ? 'bg-green-100 text-green-800 border-2 border-green-500' : 'bg-gray-100 text-gray-600 hover:bg-gray-200')}
                    >
                      {idx + 1}
                    </button>
                  )
                })}
              </div>
            </div>

          </div>
        </div>
      </div>
    )
  }

  return null
}